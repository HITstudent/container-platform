from pydantic import BaseModel
from typing import Dict, Optional
from datetime import datetime

class ContainerBase(BaseModel):
    name: str
    image: str
    ports: str
    status: str
    createdAt: str

class ContainerCreate(ContainerBase):
    pass

class ContainerResponse(ContainerBase):
    id: str

    class Config:
        orm_mode = True 