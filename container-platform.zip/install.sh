#!/bin/bash

# 设置颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 打印带颜色的消息
print_message() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# 检查命令是否存在
check_command() {
    if ! command -v $1 &> /dev/null; then
        print_message $RED "错误: $1 未安装"
        return 1
    fi
    return 0
}

# 检查Docker版本
check_docker_version() {
    local version=$(docker version --format '{{.Server.Version}}' 2>/dev/null)
    if [[ $? -ne 0 ]]; then
        print_message $RED "错误: 无法获取Docker版本"
        return 1
    fi
    
    if [[ "$(printf '%s\n' "20.10.0" "$version" | sort -V | head -n1)" != "20.10.0" ]]; then
        print_message $RED "错误: Docker版本必须大于或等于20.10.0，当前版本: $version"
        return 1
    fi
    return 0
}

# 检查Docker Compose版本
check_docker_compose_version() {
    local version=$(docker-compose version --short 2>/dev/null)
    if [[ $? -ne 0 ]]; then
        print_message $RED "错误: 无法获取Docker Compose版本"
        return 1
    fi
    
    if [[ "$(printf '%s\n' "2.0.0" "$version" | sort -V | head -n1)" != "2.0.0" ]]; then
        print_message $RED "错误: Docker Compose版本必须大于或等于2.0.0，当前版本: $version"
        return 1
    fi
    return 0
}

# 检查可用内存
check_memory() {
    local available_mem=$(free -m | awk '/^Mem:/{print $7}')
    if [[ $available_mem -lt 4096 ]]; then
        print_message $RED "错误: 可用内存不足4GB，当前可用: ${available_mem}MB"
        return 1
    fi
    return 0
}

# 检查可用磁盘空间
check_disk_space() {
    local available_space=$(df -BG . | awk 'NR==2 {print $4}' | sed 's/G//')
    if [[ $available_space -lt 10 ]]; then
        print_message $RED "错误: 可用磁盘空间不足10GB，当前可用: ${available_space}GB"
        return 1
    fi
    return 0
}

# 检查Docker守护进程配置
check_docker_daemon() {
    local os_type=$(uname -s)
    if [[ "$os_type" == "Linux" ]]; then
        if [[ ! -f "/etc/docker/daemon.json" ]]; then
            print_message $YELLOW "警告: 未找到Docker守护进程配置文件，将创建新配置"
            sudo mkdir -p /etc/docker
            echo '{
  "hosts": ["unix:///var/run/docker.sock", "tcp://0.0.0.0:2375"]
}' | sudo tee /etc/docker/daemon.json > /dev/null
            sudo systemctl restart docker
        fi
    elif [[ "$os_type" == "Darwin" ]] || [[ "$os_type" == "MINGW"* ]] || [[ "$os_type" == "MSYS"* ]]; then
        print_message $YELLOW "请确保在Docker Desktop中启用了 'Expose daemon on tcp://localhost:2375 without TLS' 选项"
    fi
}

# 创建环境变量文件
create_env_file() {
    if [[ ! -f ".env" ]]; then
        print_message $YELLOW "创建.env文件..."
        cat > .env << EOL
# PostgreSQL配置
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres
POSTGRES_DB=container_platform

# 应用配置
APP_ENV=production
DEBUG=false
SECRET_KEY=$(openssl rand -hex 32)
API_KEY=$(openssl rand -hex 32)

# Docker配置
DOCKER_HOST=tcp://host.docker.internal:2375
EOL
    fi
}

# 主安装流程
main() {
    print_message $GREEN "开始安装容器平台..."
    
    # 检查必要命令
    print_message $YELLOW "检查必要命令..."
    check_command "docker" || exit 1
    check_command "docker-compose" || exit 1
    
    # 检查系统要求
    print_message $YELLOW "检查系统要求..."
    check_docker_version || exit 1
    check_docker_compose_version || exit 1
    check_memory || exit 1
    check_disk_space || exit 1
    
    # 检查Docker配置
    print_message $YELLOW "检查Docker配置..."
    check_docker_daemon
    
    # 创建环境变量文件
    create_env_file
    
    # 启动服务
    print_message $YELLOW "启动服务..."
    docker-compose down
    docker-compose pull
    docker-compose up -d --build
    
    # 检查服务状态
    print_message $YELLOW "检查服务状态..."
    sleep 10
    if docker-compose ps | grep -q "Exit"; then
        print_message $RED "错误: 某些服务启动失败，请检查日志"
        docker-compose logs
        exit 1
    fi
    
    print_message $GREEN "安装完成！"
    print_message $GREEN "访问以下地址查看服务："
    echo "前端界面: http://localhost"
    echo "API文档: http://localhost:8000/api/v1/docs"
    echo "Prometheus: http://localhost:9090"
    echo "Grafana: http://localhost:3001 (默认账号: admin/admin)"
}

# 运行主安装流程
main 